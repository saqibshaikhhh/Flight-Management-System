package com.FMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FMS.model.Passengers;

public interface PassengersRepository extends JpaRepository<Passengers, Long>{

}
